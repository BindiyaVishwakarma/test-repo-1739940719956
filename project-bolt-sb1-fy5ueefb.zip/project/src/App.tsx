import React from 'react';
import { AlertTriangle, MapPin, ThumbsDown, Construction, Bus, Hotel } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div 
        className="h-[40vh] bg-cover bg-center relative"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1506461883276-594a12b11cf3?auto=format&fit=crop&q=80&w=2670")',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-60">
          <div className="container mx-auto px-4 h-full flex items-center">
            <div className="text-white max-w-3xl">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">The Harsh Reality of Travel in Dantewada</h1>
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                <span className="text-gray-200">Dantewada, Chhattisgarh, India</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12 max-w-3xl">
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-8">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-600" />
            <p className="text-yellow-700 font-medium">This is a critical assessment based on recent travel experiences</p>
          </div>
        </div>

        <article className="prose lg:prose-lg">
          <p className="text-xl font-medium text-gray-700 mb-6">
            The untold story of Dantewada's tourism crisis reveals a stark reality that demands immediate attention. As someone who has traversed its terrain, the gap between potential and reality is not just disappointing—it's alarming.
          </p>

          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="flex items-center gap-2 text-xl font-semibold mb-4">
              <Construction className="w-6 h-6 text-red-500" />
              Infrastructure Woes
            </h2>
            <p className="text-gray-700">
              The roads leading to Dantewada's most promising sites are in deplorable condition. What should be a 2-hour journey often turns into a 5-hour ordeal. Basic amenities like restrooms and rest stops are virtually non-existent, making it particularly challenging for families and elderly travelers.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="flex items-center gap-2 text-xl font-semibold mb-4">
              <Hotel className="w-6 h-6 text-red-500" />
              Accommodation Crisis
            </h2>
            <p className="text-gray-700">
              The handful of available accommodations fail to meet even basic standards. Most lodgings lack reliable electricity, clean water, or proper sanitation. The few decent hotels are overpriced and often fully booked months in advance, leaving travelers with limited options.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="flex items-center gap-2 text-xl font-semibold mb-4">
              <Bus className="w-6 h-6 text-red-500" />
              Transportation Nightmare
            </h2>
            <p className="text-gray-700">
              Public transportation is unreliable and infrequent. Private taxi services exploit tourists with exorbitant rates, while local buses are overcrowded and follow no fixed schedule. The absence of proper signage and navigation aids leaves visitors constantly disoriented.
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="flex items-center gap-2 text-xl font-semibold mb-4">
              <ThumbsDown className="w-6 h-6 text-red-500" />
              Call for Change
            </h2>
            <p className="text-gray-700">
              Dantewada's raw beauty deserves better. Local authorities must prioritize tourism infrastructure development. We need immediate action on road repairs, standardized accommodation regulations, and reliable public transportation. Without these fundamental changes, Dantewada's tourism potential will remain tragically unrealized.
            </p>
          </div>
        </article>

        <div className="mt-12 p-6 bg-gray-800 text-white rounded-lg">
          <h3 className="text-xl font-semibold mb-4">A Personal Note</h3>
          <p className="text-gray-300">
            This critique comes from a place of deep concern and hope for Dantewada's future. As travelers and enthusiasts, we must demand better. The region's rich cultural heritage and natural beauty are being overshadowed by these systemic failures. It's time for both authorities and stakeholders to step up and transform Dantewada into the destination it deserves to be.
          </p>
        </div>
      </main>
    </div>
  );
}

export default App;